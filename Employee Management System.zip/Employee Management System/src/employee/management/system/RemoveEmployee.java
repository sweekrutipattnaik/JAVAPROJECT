package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RemoveEmployee extends JFrame implements ActionListener {

    Choice cEmpId;
    JButton delete, back;
    JLabel labelName, labelPhone, labelEmail;

    RemoveEmployee() {
        setTitle("Remove Employee");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(245, 248, 255));
        setLayout(null);

        JLabel heading = new JLabel("Remove Employee");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 28));
        heading.setForeground(new Color(60, 90, 150));
        heading.setBounds(180, 20, 300, 40);
        add(heading);

        JLabel labelEmpId = new JLabel("Select Employee ID:");
        labelEmpId.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        labelEmpId.setBounds(50, 80, 160, 25);
        add(labelEmpId);

        cEmpId = new Choice();
        cEmpId.setBounds(220, 80, 200, 25);
        cEmpId.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        add(cEmpId);

        // Panel for Employee Info
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(3, 2, 10, 15));
        infoPanel.setBounds(50, 130, 500, 130);
        infoPanel.setBackground(new Color(255, 255, 255));
        infoPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 255), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        infoPanel.add(new JLabel("Name:", JLabel.RIGHT));
        labelName = new JLabel();
        labelName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoPanel.add(labelName);

        infoPanel.add(new JLabel("Phone:", JLabel.RIGHT));
        labelPhone = new JLabel();
        labelPhone.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoPanel.add(labelPhone);

        infoPanel.add(new JLabel("Email:", JLabel.RIGHT));
        labelEmail = new JLabel();
        labelEmail.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoPanel.add(labelEmail);

        add(infoPanel);

        delete = createButton("❌ Delete");
        delete.setBounds(120, 300, 140, 40);
        add(delete);

        back = createButton("🔙 Back");
        back.setBounds(300, 300, 140, 40);
        add(back);

        // Load employee IDs
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM employee");
            while (rs.next()) {
                cEmpId.add(rs.getString("empId"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        updateEmployeeDetails(); // Show initial selection

        cEmpId.addItemListener(e -> updateEmployeeDetails());

        delete.addActionListener(this);
        back.addActionListener(this);

        setVisible(true);
    }

    private void updateEmployeeDetails() {
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM employee WHERE empId = '" + cEmpId.getSelectedItem() + "'");
            if (rs.next()) {
                labelName.setText(rs.getString("name"));
                labelPhone.setText(rs.getString("phone"));
                labelEmail.setText(rs.getString("email"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setBackground(new Color(100, 149, 237));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setOpaque(true);

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(65, 105, 225));
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(100, 149, 237));
            }
        });

        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == delete) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this employee?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Conn c = new Conn();
                    String query = "DELETE FROM employee WHERE empId = '" + cEmpId.getSelectedItem() + "'";
                    c.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(this, "Employee Deleted Successfully");

                    setVisible(false);
                    new Home();
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Failed to delete employee");
                }
            }
        } else if (ae.getSource() == back) {
            setVisible(false);
            new Home();
        }
    }

    public static void main(String[] args) {
        new RemoveEmployee();
    }
}

