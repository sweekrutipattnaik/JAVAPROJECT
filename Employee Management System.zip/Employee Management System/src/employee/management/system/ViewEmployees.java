package employee.management.system;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class ViewEmployees extends JFrame implements ActionListener {

    JTable table;
    JButton updateButton;
    boolean updateMode;

    ViewEmployees() {
        this(false);
    }

    ViewEmployees(boolean updateMode) {
        this.updateMode = updateMode;

        setTitle(updateMode ? "Update Employee Records" : "View All Employees");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 248, 255));

        // Heading
        JLabel heading = new JLabel(updateMode ? "Update Employee Records" : "Employee Directory", JLabel.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 26));
        heading.setForeground(new Color(40, 70, 130));
        heading.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));
        add(heading, BorderLayout.NORTH);

        // Table styling and loading data
        table = new JTable();
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(230, 230, 250));
        table.setGridColor(new Color(220, 220, 220));

        try {
            Conn c = new Conn();
            String query = "SELECT * FROM employee";
            ResultSet rs = c.s.executeQuery(query);
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employee data");
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        add(scrollPane, BorderLayout.CENTER);

        // Update button section if updateMode is true
        if (updateMode) {
            updateButton = createStyledButton("✏️ Update Selected Employee", new Color(255, 140, 0));
            updateButton.addActionListener(this);
            JPanel buttonPanel = new JPanel();
            buttonPanel.setBackground(new Color(245, 248, 255));
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
            buttonPanel.add(updateButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        setVisible(true);
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setOpaque(true);

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bg.darker());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(bg);
            }
        });

        return button;
    }

    public void actionPerformed(ActionEvent e) {
        int row = table.getSelectedRow();
        if (row != -1) {
            String empId = table.getValueAt(row, 9).toString(); // empId assumed at column index 9
            setVisible(false);
            new UpdateEmployee(empId);
        } else {
            JOptionPane.showMessageDialog(this, "Please select an employee to update.");
        }
    }

    public static void main(String[] args) {
        new ViewEmployees();
    }
}
