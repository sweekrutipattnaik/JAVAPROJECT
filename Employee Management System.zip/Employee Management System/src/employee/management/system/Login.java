package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    JTextField tfusername;
    JPasswordField pfpassword;
    JButton login;
    JCheckBox showPassword;

    Login() {
        setTitle("Employee Management System - Login");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(230, 240, 250));
        setLayout(null);

        // Login Panel
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(null);
        loginPanel.setBounds(75, 50, 350, 270);
        loginPanel.setBackground(Color.WHITE);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        add(loginPanel);

        JLabel heading = new JLabel("Employee Login");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        heading.setForeground(new Color(50, 70, 120));
        heading.setBounds(90, 10, 200, 30);
        loginPanel.add(heading);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUsername.setBounds(30, 60, 80, 25);
        loginPanel.add(lblUsername);

        tfusername = new JTextField();
        tfusername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tfusername.setBounds(120, 60, 180, 30);
        loginPanel.add(tfusername);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPassword.setBounds(30, 110, 80, 25);
        loginPanel.add(lblPassword);

        pfpassword = new JPasswordField();
        pfpassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        pfpassword.setBounds(120, 110, 180, 30);
        loginPanel.add(pfpassword);

        showPassword = new JCheckBox("Show Password");
        showPassword.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        showPassword.setBackground(Color.WHITE);
        showPassword.setBounds(120, 145, 150, 20);
        loginPanel.add(showPassword);
        showPassword.addActionListener(e -> {
            if (showPassword.isSelected()) {
                pfpassword.setEchoChar((char) 0);
            } else {
                pfpassword.setEchoChar('\u2022');
            }
        });

        login = new JButton("Login");
        login.setFont(new Font("Segoe UI", Font.BOLD, 14));
        login.setBackground(new Color(60, 130, 200));
        login.setForeground(Color.WHITE);
        login.setFocusPainted(false);
        login.setBounds(120, 185, 100, 35);
        login.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effect
        login.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                login.setBackground(new Color(40, 110, 180));
            }

            public void mouseExited(MouseEvent e) {
                login.setBackground(new Color(60, 130, 200));
            }
        });

        login.addActionListener(this);
        loginPanel.add(login);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String username = tfusername.getText();
        String password = String.valueOf(pfpassword.getPassword());

        try {
            Conn c = new Conn();
            String query = "SELECT * FROM login WHERE username = ? AND password = ?";
            PreparedStatement ps = c.c.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Login Successful");
                setVisible(false);
                new Home().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
