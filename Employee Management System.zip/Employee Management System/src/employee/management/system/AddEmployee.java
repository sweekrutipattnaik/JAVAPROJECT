package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddEmployee extends JFrame implements ActionListener {

    JTextField tfName, tfFname, tfSalary, tfPhone, tfEmail, tfDesignation, tfAadhar, tfEmpId;
    JComboBox<String> cbEducation, cbDay, cbMonth, cbYear;
    JButton add, back;

    AddEmployee() {
        setTitle("Add Employee");
        setSize(900, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 248, 255));

        // Title
        JLabel heading = new JLabel("Add Employee Details", JLabel.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 30));
        heading.setForeground(new Color(40, 70, 130));
        heading.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(heading, BorderLayout.NORTH);

        // Center panel for form
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        add(formPanel, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Components
        tfName = createTextField();
        tfFname = createTextField();
        tfSalary = createTextField();
        tfPhone = createTextField();
        tfEmail = createTextField();
        tfDesignation = createTextField();
        tfAadhar = createTextField();
        tfEmpId = createTextField();

        cbEducation = new JComboBox<>(new String[] { "10th", "12th", "BTech", "BCA", "BBA", "BA", "MCA", "MBA", "MA", "MTech", "PhD" });

        cbDay = new JComboBox<>();
        for (int i = 1; i <= 31; i++) cbDay.addItem(String.valueOf(i));
        cbMonth = new JComboBox<>(new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" });
        cbYear = new JComboBox<>();
        for (int i = 1975; i <= 2024; i++) cbYear.addItem(String.valueOf(i));

        // Add form fields row by row
        addFormRow(formPanel, gbc, "Name", tfName);
        addFormRow(formPanel, gbc, "Father's Name", tfFname);
        addFormRow(formPanel, gbc, "Date of Birth", new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0)) {{
            add(cbDay);
            add(cbMonth);
            add(cbYear);
        }});
        addFormRow(formPanel, gbc, "Salary", tfSalary);
        addFormRow(formPanel, gbc, "Phone", tfPhone);
        addFormRow(formPanel, gbc, "Email", tfEmail);
        addFormRow(formPanel, gbc, "Education", cbEducation);
        addFormRow(formPanel, gbc, "Designation", tfDesignation);
        addFormRow(formPanel, gbc, "Aadhar Number", tfAadhar);
        addFormRow(formPanel, gbc, "Employee ID", tfEmpId);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.WHITE);

        add = createButton("Add Employee", new Color(34, 139, 34));
        back = createButton("Back", new Color(220, 20, 60));

        buttonPanel.add(add);
        buttonPanel.add(back);
        add(buttonPanel, BorderLayout.SOUTH);

        add.addActionListener(this);
        back.addActionListener(this);

        setVisible(true);
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, String label, Component input) {
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 0;
        panel.add(jLabel, gbc);

        gbc.gridx = 1;
        panel.add(input, gbc);
        gbc.gridy++;
    }

    private JTextField createTextField() {
        JTextField tf = new JTextField(20);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return tf;
    }

    private JButton createButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(150, 40));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(bg.darker());
            }
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });

        return btn;
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            String name = tfName.getText();
            String fname = tfFname.getText();
            String dob = cbDay.getSelectedItem() + "-" + cbMonth.getSelectedItem() + "-" + cbYear.getSelectedItem();
            String salary = tfSalary.getText();
            String phone = tfPhone.getText();
            String email = tfEmail.getText();
            String education = (String) cbEducation.getSelectedItem();
            String designation = tfDesignation.getText();
            String aadhar = tfAadhar.getText();
            String empId = tfEmpId.getText();

            try {
                Conn conn = new Conn();
                String query = "INSERT INTO employee VALUES ('" + name + "', '" + fname + "', '" + dob + "', '" + salary + "', '" + phone + "', '" + email + "', '" + education + "', '" + designation + "', '" + aadhar + "', '" + empId + "')";
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Employee Added Successfully");
                setVisible(false);
                new Home();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: Could not add employee");
            }
        } else {
            setVisible(false);
            new Home();
        }
    }

    public static void main(String[] args) {
        new AddEmployee();
    }
}
