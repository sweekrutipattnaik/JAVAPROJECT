package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateEmployee extends JFrame implements ActionListener {

    JTextField tfname, tffname, tfsalary, tfphone, tfemail, tfeducation, tfdesignation, tfaadhar;
    JComboBox<String> cbday, cbmonth, cbyear;
    JLabel lblempId;
    JButton update, back;
    String empId;

    UpdateEmployee(String empId) {
        this.empId = empId;

        setTitle("Update Employee");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 250, 255));

        JLabel heading = new JLabel("Update Employee Details");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 26));
        heading.setBounds(280, 20, 400, 30);
        heading.setForeground(new Color(30, 60, 120));
        add(heading);

        int y = 80;
        int labelX = 50, fieldX = 200, fieldW = 180, h = 30, gap = 50;

        addLabel("Employee ID", labelX, y);
        lblempId = new JLabel();
        lblempId.setBounds(fieldX, y, fieldW, h);
        lblempId.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        add(lblempId);

        addLabel("Name", 470, y);
        tfname = createTextField(620, y);
        add(tfname);

        y += gap;
        addLabel("Father's Name", labelX, y);
        tffname = createTextField(fieldX, y);
        add(tffname);

        addLabel("Date of Birth", 470, y);
        cbday = new JComboBox<>(generateNumbers(1, 31));
        cbmonth = new JComboBox<>(getMonths());
        cbyear = new JComboBox<>(generateNumbers(1970, 2010));
        cbday.setBounds(620, y, 50, h);
        cbmonth.setBounds(675, y, 80, h);
        cbyear.setBounds(760, y, 70, h);
        add(cbday); add(cbmonth); add(cbyear);

        y += gap;
        addLabel("Salary", labelX, y);
        tfsalary = createTextField(fieldX, y);
        add(tfsalary);

        addLabel("Phone", 470, y);
        tfphone = createTextField(620, y);
        add(tfphone);

        y += gap;
        addLabel("Email", labelX, y);
        tfemail = createTextField(fieldX, y);
        add(tfemail);

        addLabel("Education", 470, y);
        tfeducation = createTextField(620, y);
        add(tfeducation);

        y += gap;
        addLabel("Designation", labelX, y);
        tfdesignation = createTextField(fieldX, y);
        add(tfdesignation);

        addLabel("Aadhar No", 470, y);
        tfaadhar = createTextField(620, y);
        add(tfaadhar);

        update = createButton("Update", 250, y + 60, new Color(34, 139, 34));
        back = createButton("Back", 450, y + 60, new Color(220, 20, 60));
        add(update); add(back);

        update.addActionListener(this);
        back.addActionListener(this);

        showEmployeeDetails();

        setVisible(true);
    }

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setBounds(x, y, 150, 30);
        add(label);
    }

    private JTextField createTextField(int x, int y) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBounds(x, y, 180, 30);
        return tf;
    }

    private JButton createButton(String text, int x, int y, Color bg) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, 150, 35);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private String[] generateNumbers(int start, int end) {
        String[] arr = new String[end - start + 1];
        for (int i = 0; i < arr.length; i++) arr[i] = String.valueOf(start + i);
        return arr;
    }

    private String[] getMonths() {
        return new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    }

    private void showEmployeeDetails() {
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM employee WHERE empId = '" + empId + "'");
            if (rs.next()) {
                lblempId.setText(rs.getString("empId"));
                tfname.setText(rs.getString("name"));
                tffname.setText(rs.getString("fname"));
                String[] dobParts = rs.getString("dob").split("-");
                if (dobParts.length == 3) {
                    cbday.setSelectedItem(dobParts[0]);
                    cbmonth.setSelectedIndex(Integer.parseInt(dobParts[1]) - 1);
                    cbyear.setSelectedItem(dobParts[2]);
                }
                tfsalary.setText(rs.getString("salary"));
                tfphone.setText(rs.getString("phone"));
                tfemail.setText(rs.getString("email"));
                tfeducation.setText(rs.getString("education"));
                tfdesignation.setText(rs.getString("designation"));
                tfaadhar.setText(rs.getString("aadhar"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == update) {
            String name = tfname.getText();
            String fname = tffname.getText();
            String dob = cbday.getSelectedItem() + "-" + (cbmonth.getSelectedIndex() + 1) + "-" + cbyear.getSelectedItem();
            String salary = tfsalary.getText();
            String phone = tfphone.getText();
            String email = tfemail.getText();
            String education = tfeducation.getText();
            String designation = tfdesignation.getText();
            String aadhar = tfaadhar.getText();

            try {
                Conn c = new Conn();
                String query = "UPDATE employee SET name='" + name + "', fname='" + fname + "', dob='" + dob + "', salary='" + salary + "', phone='" + phone + "', email='" + email + "', education='" + education + "', designation='" + designation + "', aadhar='" + aadhar + "' WHERE empId='" + empId + "'";
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(this, "Employee details updated successfully.");
                setVisible(false);
                new Home();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to update employee.");
            }
        } else {
            setVisible(false);
            new Home();
        }
    }

    public static void main(String[] args) {
        new UpdateEmployee("1001"); // sample empId
    }
}
