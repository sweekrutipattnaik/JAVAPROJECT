package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Splash extends JFrame implements ActionListener {
    JButton clickHere;

    Splash() {
        setTitle("Employee Management System");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setLayout(null);

        // Main Heading with blinking effect
        JLabel heading = new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
        heading.setBounds(50, 50, 700, 60);
        heading.setFont(new Font("Serif", Font.BOLD, 36));
        heading.setForeground(new Color(0, 102, 204));
        add(heading);

        // Blinking effect using Swing Timer
        Timer blinkTimer = new Timer(500, new ActionListener() {
            private boolean visible = true;

            @Override
            public void actionPerformed(ActionEvent e) {
                heading.setVisible(visible);
                visible = !visible;
            }
        });
        blinkTimer.start();

        // Click Button
        clickHere = new JButton("Click here to continue");
        clickHere.setBounds(275, 220, 250, 45);
        clickHere.setBackground(new Color(0, 102, 204));
        clickHere.setForeground(Color.WHITE);
        clickHere.setFont(new Font("Tahoma", Font.PLAIN, 18));
        clickHere.addActionListener(this);
        add(clickHere);

        // Set background color
        getContentPane().setBackground(Color.LIGHT_GRAY);

        // Window settings
        setUndecorated(true); // Removes the default window borders
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Login(); // Assuming Login is another JFrame class that opens next
    }

    public static void main(String[] args) {
        new Splash();
    }
}