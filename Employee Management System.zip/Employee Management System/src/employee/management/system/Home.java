package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Home extends JFrame implements ActionListener {

    JButton add, view, update, remove;

    Home() {
        setTitle("Employee Management System - Home");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 248, 255));

        // Heading
        JLabel heading = new JLabel("Employee Management Dashboard", JLabel.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 28));
        heading.setForeground(new Color(40, 70, 130));
        heading.setBorder(BorderFactory.createEmptyBorder(30, 10, 20, 10));
        add(heading, BorderLayout.NORTH);

        // Panel with GridLayout for buttons
        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 150, 30, 150));

        // Create buttons
        add = createStyledButton(" Add Employee", new Color(34, 139, 34));
        view = createStyledButton("️ View Employees", new Color(30, 144, 255));
        update = createStyledButton(" Update Employee", new Color(255, 140, 0));
        remove = createStyledButton(" Remove Employee", new Color(220, 20, 60));

        // Add buttons to panel
        buttonPanel.add(add);
        buttonPanel.add(view);
        buttonPanel.add(update);
        buttonPanel.add(remove);

        add(buttonPanel, BorderLayout.CENTER);

        // Add listeners
        add.addActionListener(this);
        view.addActionListener(this);
        update.addActionListener(this);
        remove.addActionListener(this);

        setVisible(true);
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setOpaque(true);

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bg.darker());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(bg);
            }
        });

        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            new AddEmployee();
        } else if (ae.getSource() == view) {
            new ViewEmployees();
        } else if (ae.getSource() == update) {
            new ViewEmployees(true); // Update mode
        } else if (ae.getSource() == remove) {
            new RemoveEmployee();
        }
    }

    public static void main(String[] args) {
        new Home();
    }
}
